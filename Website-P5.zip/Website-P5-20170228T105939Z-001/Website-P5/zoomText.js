

var zxcBlankImg='http://www.vicsjavascripts.org.uk/StdImages/Blank.gif'; 
var zxcOOPCnt=0;

function zxcZoomText(zxcobj,zxcssz,zxcfsz,zxcspd){
 if (typeof(zxcobj)=='string'){ zxcobj=document.getElementById(obj); }
 if (!zxcobj.oopct){
  zxcspd=zxcspd||100;
  if (zxcBlankImg){ zxcobj.style.backgroundImage='url('+zxcBlankImg+')'; }
  zxcobj.oopct=new zxcOOPTxtZoom(zxcobj,zxcssz,zxcfsz,zxcspd);
 }
 clearTimeout(zxcobj.oopct.to);
 zxcobj.oopct.minmax[4]*=-1;
 zxcobj.oopct.cngtxt();
}

function zxcOOPTxtZoom(zxcobj,zxcssz,zxcfsz,zxcspd){
 this.obj=zxcobj;
 if (zxcobj.style.position){
  if (zxcobj.style.position='absolute'){
   this.abs=[zxcobj.offsetLeft,zxcobj.offsetWidth];
  }
 }
 this.ref='zxcoopct'+zxcOOPCnt++;
 window[this.ref]=this;
 this.minmax=[zxcssz,Math.min(zxcssz,zxcfsz),Math.max(zxcssz,zxcfsz),zxcspd,(zxcssz<zxcfsz)?-1:1];
 this.to=null;
}

zxcOOPTxtZoom.prototype.cngtxt=function(){
 if ((this.minmax[4]>0&&this.minmax[0]<this.minmax[2])||(this.minmax[4]<0&&this.minmax[0]>this.minmax[1])){
  this.obj.style.fontSize=(this.minmax[0]+=this.minmax[4])+'px';
  if (this.abs){
   this.obj.parentNode.style.width=(this.obj.offsetWidth+parseInt(this.obj.style.fontSize))+'px';
   this.obj.parentNode.style.left=(parseInt(this.obj.style.fontSize)/2)+'px';
  }
  this.to=this.setTimeOut('cngtxt();',this.minmax[3]);
 }
}

zxcOOPTxtZoom.prototype.setTimeOut=function(zxcf,zxcd){
 this.to=setTimeout('window.'+this.ref+'.'+zxcf,zxcd);
}



